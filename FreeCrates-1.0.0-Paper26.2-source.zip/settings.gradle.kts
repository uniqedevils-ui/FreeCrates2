rootProject.name = "FreeCrates"
