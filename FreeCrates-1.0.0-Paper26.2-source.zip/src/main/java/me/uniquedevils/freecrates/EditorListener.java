package me.uniquedevils.freecrates;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

public class EditorListener implements Listener {
    private final FreeCrates plugin;
    private final Map<Player, String> menus = new HashMap<>();

    public EditorListener(FreeCrates plugin) {
        this.plugin = plugin;
    }

    public void openMain(Player p) {
        menus.put(p, "main");
        Inventory inv = Bukkit.createInventory(null, 54, Util.component("&8FreeCrates &bEditor"));
        int slot = 10;
        for (Crate c : plugin.crates().getCrates().values()) {
            inv.setItem(slot++, Util.item(c.getIcon(), c.getDisplayName(), 1));
            if (slot == 17 || slot == 26 || slot == 35 || slot == 44) slot++;
        }
        inv.setItem(49, Util.item(Material.EMERALD, "&a&lCREATE CRATE", "&7Click to create a crate", "&8You will enter the name in chat."));
        inv.setItem(53, Util.item(Material.BARRIER, "&c&lCLOSE"));
        p.openInventory(inv);
    }

    private void openCrate(Player p, Crate c) {
        menus.put(p, "crate:" + c.getId());
        Inventory inv = Bukkit.createInventory(null, 54, Util.component("&8Edit &b" + c.getId()));
        inv.setItem(10, Util.item(c.getIcon(), c.getDisplayName(), 1));
        inv.setItem(12, Util.item(Material.NAME_TAG, "&e&lNAME", "&7Click then type a new name in chat."));
        inv.setItem(14, Util.item(Material.TRIPWIRE_HOOK, "&a&lKEY NAME", "&7Click then type a new key name."));
        inv.setItem(16, Util.item(Material.CLOCK, "&b&lANIMATION", "&7Current: &f" + c.getAnimation()));
        inv.setItem(28, Util.item(Material.CHEST, "&6&lREWARDS", "&7Manage rewards & chances."));
        inv.setItem(30, Util.item(Material.ENDER_CHEST, "&d&lPREVIEW", "&7Preview this crate."));
        inv.setItem(32, Util.item(Material.REDSTONE_TORCH, "&c&lDELETE", "&7Delete this crate."));
        inv.setItem(49, Util.item(Material.ARROW, "&7Back"));
        p.openInventory(inv);
    }

    private void openRewards(Player p, Crate c) {
        menus.put(p, "rewards:" + c.getId());
        Inventory inv = Bukkit.createInventory(null, 54, Util.component("&8Rewards &b" + c.getId()));
        int slot = 0;
        for (Reward r : c.getRewards()) {
            ItemStack item = r.getItem();
            if (item == null || item.getType().isAir()) item = Util.item(Material.BARRIER, r.getDisplayName());
            else item = item.clone();
            var meta = item.getItemMeta();
            if (meta != null) {
                meta.displayName(Util.component(r.getDisplayName()));
                meta.lore(Util.lore(
                        "&7Rarity: &f" + r.getRarity(),
                        "&7Chance: &f" + r.getChance() + "%",
                        "&7Broadcast: &f" + r.isBroadcast(),
                        "&8Click to edit"
                ));
                item.setItemMeta(meta);
            }
            if (slot < 45) inv.setItem(slot++, item);
        }
        inv.setItem(49, Util.item(Material.EMERALD, "&a&lADD REWARD", "&7Place the reward item in your cursor", "&7then click this button."));
        inv.setItem(53, Util.item(Material.ARROW, "&7Back"));
        p.openInventory(inv);
    }

    private void openReward(Player p, Crate c, Reward r) {
        menus.put(p, "reward:" + c.getId() + ":" + r.getId());
        Inventory inv = Bukkit.createInventory(null, 27, Util.component("&8Reward &b" + r.getId()));
        ItemStack item = r.getItem();
        if (item == null) item = Util.item(Material.BARRIER, "&cNo item");
        inv.setItem(4, item);
        inv.setItem(10, Util.item(Material.NAME_TAG, "&e&lDISPLAY NAME", "&7" + r.getDisplayName()));
        inv.setItem(12, Util.item(Material.COMPASS, "&b&lCHANCE", "&7" + r.getChance() + "%", "&8Shift-click: -1% | Normal: +1%"));
        inv.setItem(14, Util.item(Material.AMETHYST_SHARD, "&d&lRARITY", "&7" + r.getRarity(), "&8Click to cycle"));
        inv.setItem(16, Util.item(Material.BELL, "&6&lBROADCAST", "&7" + r.isBroadcast(), "&8Click to toggle"));
        inv.setItem(22, Util.item(Material.ARROW, "&7Back"));
        p.openInventory(inv);
    }

    @EventHandler
    public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String menu = menus.get(p);
        if (menu == null) return;
        if (!e.getView().title().toString().contains("FreeCrates") &&
            !e.getView().title().toString().contains("Edit") &&
            !e.getView().title().toString().contains("Rewards") &&
            !e.getView().title().toString().contains("Reward")) return;

        e.setCancelled(true);
        int slot = e.getRawSlot();
        if (slot < 0 || slot >= e.getView().getTopInventory().getSize()) return;

        if (menu.equals("main")) {
            if (slot == 49) {
                p.closeInventory();
                p.sendMessage(Util.component("&bFreeCrates &8» &7Type the new crate ID in chat."));
                p.sendMessage(Util.component("&8Example: &fVIP"));

                ChatInput.await(p, "create", plugin, null, null);
                return;
            }
            if (slot == 53) { p.closeInventory(); return; }
            ItemStack clicked = e.getCurrentItem();
            if (clicked != null && !clicked.getType().isAir()) {
                for (Crate c : plugin.crates().getCrates().values()) {
                    if (clicked.getType() == c.getIcon()) { openCrate(p, c); break; }
                }
            }
            return;
        }

        if (menu.startsWith("crate:")) {
            Crate c = plugin.crates().get(menu.substring(6));
            if (c == null) { openMain(p); return; }
            if (slot == 28) { openRewards(p, c); return; }
            if (slot == 30) {
                p.closeInventory();
                p.sendMessage(Util.component("&bPreview &8» &7" + c.getDisplayName()));
                for (Reward r : c.getRewards())
                    p.sendMessage(Util.component("&8• &f" + r.getDisplayName() + " &7(" + r.getChance() + "%) &8[" + r.getRarity() + "]"));
                return;
            }
            if (slot == 32) { plugin.crates().delete(c.getId()); openMain(p); return; }
            if (slot == 12) { p.closeInventory(); ChatInput.await(p, "name", plugin, c, null); return; }
            if (slot == 14) { p.closeInventory(); ChatInput.await(p, "keyname", plugin, c, null); return; }
            if (slot == 16) {
                c.setAnimation(c.getAnimation().equalsIgnoreCase("CSGO") ? "SPIN" : "CSGO");
                plugin.crates().save(); openCrate(p, c); return;
            }
            if (slot == 49) { openMain(p); }
            return;
        }

        if (menu.startsWith("rewards:")) {
            Crate c = plugin.crates().get(menu.substring(8));
            if (c == null) { openMain(p); return; }
            if (slot == 49) {
                ItemStack cursor = e.getCursor();
                Reward r = new Reward("reward" + (c.getRewards().size() + 1));
                r.setDisplayName("&fNew Reward");
                r.setRarity("COMMON");
                r.setChance(1.0);
                if (cursor != null && !cursor.getType().isAir()) r.setItem(cursor);
                else r.setItem(new ItemStack(Material.DIAMOND));
                c.getRewards().add(r);
                plugin.crates().save();
                openRewards(p, c);
                return;
            }
            if (slot == 53) { openCrate(p, c); return; }
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || clicked.getType().isAir()) return;
            int index = slot;
            if (index < c.getRewards().size()) openReward(p, c, c.getRewards().get(index));
            return;
        }

        if (menu.startsWith("reward:")) {
            String[] parts = menu.split(":");
            Crate c = plugin.crates().get(parts[1]);
            if (c == null) { openMain(p); return; }
            Reward r = plugin.crates().findReward(c, parts[2]);
            if (r == null) { openRewards(p, c); return; }

            if (slot == 10) { p.closeInventory(); ChatInput.await(p, "rewardname", plugin, c, r); return; }
            if (slot == 12) {
                double n = r.getChance() + (e.isShiftClick() ? -1.0 : 1.0);
                r.setChance(Math.max(0, Math.min(100, n)));
                plugin.crates().save(); openReward(p, c, r); return;
            }
            if (slot == 14) {
                String[] rarities = {"COMMON", "UNCOMMON", "RARE", "EPIC", "LEGENDARY", "ULTRA"};
                int i = 0;
                for (int x = 0; x < rarities.length; x++) if (rarities[x].equalsIgnoreCase(r.getRarity())) i = x;
                r.setRarity(rarities[(i + 1) % rarities.length]);
                plugin.crates().save(); openReward(p, c, r); return;
            }
            if (slot == 16) { r.setBroadcast(!r.isBroadcast()); plugin.crates().save(); openReward(p, c, r); return; }
            if (slot == 4 && e.getCursor() != null && !e.getCursor().getType().isAir()) {
                r.setItem(e.getCursor());
                plugin.crates().save(); openReward(p, c, r);
                return;
            }
            if (slot == 22) { openRewards(p, c); }
        }
    }

    @EventHandler
    public void close(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player p) menus.remove(p);
    }
}
