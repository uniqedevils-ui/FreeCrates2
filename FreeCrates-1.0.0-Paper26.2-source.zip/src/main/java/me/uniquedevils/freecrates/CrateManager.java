package me.uniquedevils.freecrates;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class CrateManager {
    private final FreeCrates plugin;
    private final Map<String, Crate> crates = new LinkedHashMap<>();

    public CrateManager(FreeCrates plugin) {
        this.plugin = plugin;
        load();
    }

    public Map<String, Crate> getCrates() { return crates; }

    public Crate get(String id) {
        if (id == null) return null;
        for (Map.Entry<String, Crate> e : crates.entrySet()) {
            if (e.getKey().equalsIgnoreCase(id)) return e.getValue();
        }
        return null;
    }

    public void load() {
        crates.clear();
        ConfigurationSection root = plugin.getConfig().getConfigurationSection("crates");
        if (root == null) return;

        for (String id : root.getKeys(false)) {
            ConfigurationSection sec = root.getConfigurationSection(id);
            if (sec == null) continue;
            Crate c = new Crate(id);
            c.setDisplayName(sec.getString("display-name", "&b" + id));
            c.setIcon(Util.material(sec.getString("icon", "CHEST"), Material.CHEST));
            c.setKeyName(sec.getString("key-name", "&b" + id + " Key"));
            c.setAnimation(sec.getString("animation", "CSGO"));

            ConfigurationSection rewards = sec.getConfigurationSection("rewards");
            if (rewards != null) {
                for (String rid : rewards.getKeys(false)) {
                    ConfigurationSection rs = rewards.getConfigurationSection(rid);
                    if (rs == null) continue;
                    Reward r = new Reward(rid);
                    r.setDisplayName(rs.getString("display-name", "&fReward"));
                    r.setRarity(rs.getString("rarity", "COMMON"));
                    r.setChance(rs.getDouble("chance", 1.0));
                    r.setBroadcast(rs.getBoolean("broadcast", false));
                    ItemStack item = rs.getItemStack("item");
                    if (item != null) r.setItem(item);
                    r.getCommands().addAll(rs.getStringList("commands"));
                    c.getRewards().add(r);
                }
            }
            crates.put(id, c);
        }
    }

    public void save() {
        for (String key : new ArrayList<>(plugin.getConfig().getConfigurationSection("crates").getKeys(false))) {
            plugin.getConfig().set("crates." + key, null);
        }

        for (Crate c : crates.values()) {
            String base = "crates." + c.getId();
            plugin.getConfig().set(base + ".display-name", c.getDisplayName());
            plugin.getConfig().set(base + ".icon", c.getIcon().name());
            plugin.getConfig().set(base + ".key-name", c.getKeyName());
            plugin.getConfig().set(base + ".animation", c.getAnimation());

            for (Reward r : c.getRewards()) {
                String rb = base + ".rewards." + r.getId();
                plugin.getConfig().set(rb + ".display-name", r.getDisplayName());
                plugin.getConfig().set(rb + ".rarity", r.getRarity());
                plugin.getConfig().set(rb + ".chance", r.getChance());
                plugin.getConfig().set(rb + ".broadcast", r.isBroadcast());
                plugin.getConfig().set(rb + ".item", r.getItem());
                plugin.getConfig().set(rb + ".commands", r.getCommands());
            }
        }
        plugin.saveConfig();
    }

    public void create(String id) {
        crates.put(id, new Crate(id));
        save();
    }

    public void delete(String id) {
        Crate c = get(id);
        if (c != null) crates.remove(c.getId());
        save();
    }

    public Reward findReward(Crate crate, String id) {
        for (Reward r : crate.getRewards()) if (r.getId().equalsIgnoreCase(id)) return r;
        return null;
    }

    public Reward pick(Crate crate) {
        List<Reward> rewards = crate.getRewards();
        if (rewards.isEmpty()) return null;
        double total = 0;
        for (Reward r : rewards) if (r.getChance() > 0) total += r.getChance();
        if (total <= 0) return rewards.get(new Random().nextInt(rewards.size()));
        double roll = Math.random() * total;
        double cursor = 0;
        for (Reward r : rewards) {
            if (r.getChance() <= 0) continue;
            cursor += r.getChance();
            if (roll <= cursor) return r;
        }
        return rewards.get(rewards.size() - 1);
    }
}
