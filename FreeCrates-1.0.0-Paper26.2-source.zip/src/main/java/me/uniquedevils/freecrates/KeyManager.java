package me.uniquedevils.freecrates;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class KeyManager {
    private final FreeCrates plugin;
    private final NamespacedKey keyTag;
    private final Map<UUID, Map<String, Integer>> virtual = new HashMap<>();

    public KeyManager(FreeCrates plugin) {
        this.plugin = plugin;
        keyTag = new NamespacedKey(plugin, "crate_key");
    }

    public ItemStack createKey(Crate crate, int amount) {
        ItemStack item = new ItemStack(Material.TRIPWIRE_HOOK, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Util.component(crate.getKeyName()));
        meta.getPersistentDataContainer().set(keyTag, PersistentDataType.STRING, crate.getId());
        meta.lore(Util.lore("&7Use this key at a &f" + Util.plain(crate.getDisplayName()) + "&7.", "&8Right-click a crate."));
        item.setItemMeta(meta);
        return item;
    }

    public String keyCrate(ItemStack item) {
        if (item == null || item.getType() != Material.TRIPWIRE_HOOK || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(keyTag, PersistentDataType.STRING);
    }

    public boolean consumePhysical(Player player, Crate crate) {
        ItemStack main = player.getInventory().getItemInMainHand();
        String id = keyCrate(main);
        if (id == null || !id.equalsIgnoreCase(crate.getId())) return false;
        if (main.getAmount() <= 1) player.getInventory().setItemInMainHand(null);
        else main.setAmount(main.getAmount() - 1);
        return true;
    }

    public void addVirtual(Player p, Crate c, int amount) {
        virtual.computeIfAbsent(p.getUniqueId(), x -> new HashMap<>())
                .merge(c.getId(), amount, Integer::sum);
    }

    public int virtualAmount(Player p, Crate c) {
        return virtual.getOrDefault(p.getUniqueId(), Map.of()).getOrDefault(c.getId(), 0);
    }

    public boolean consumeVirtual(Player p, Crate c) {
        Map<String, Integer> map = virtual.get(p.getUniqueId());
        if (map == null) return false;
        int n = map.getOrDefault(c.getId(), 0);
        if (n <= 0) return false;
        map.put(c.getId(), n - 1);
        return true;
    }

    public Map<String, Integer> getVirtual(Player p) {
        return virtual.getOrDefault(p.getUniqueId(), Map.of());
    }
}
