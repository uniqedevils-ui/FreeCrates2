package me.uniquedevils.freecrates;

import org.bukkit.plugin.java.JavaPlugin;

public final class FreeCrates extends JavaPlugin {
    private CrateManager crateManager;
    private KeyManager keyManager;
    private HistoryManager historyManager;
    private CrateListener crateListener;
    private EditorListener editorListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        crateManager = new CrateManager(this);
        keyManager = new KeyManager(this);
        historyManager = new HistoryManager(this);

        CratesCommand command = new CratesCommand(this);
        getCommand("crates").setExecutor(command);
        getCommand("crates").setTabCompleter(command);

        crateListener = new CrateListener(this);
        editorListener = new EditorListener(this);
        getServer().getPluginManager().registerEvents(crateListener, this);
        getServer().getPluginManager().registerEvents(editorListener, this);
        getServer().getPluginManager().registerEvents(new ChatInput(), this);

        getLogger().info("FreeCrates enabled. Loaded " + crateManager.getCrates().size() + " crates.");
    }

    @Override
    public void onDisable() {
        if (crateManager != null) crateManager.save();
        if (historyManager != null) historyManager.save();
    }

    public CrateManager crates() { return crateManager; }
    public KeyManager keys() { return keyManager; }
    public HistoryManager history() { return historyManager; }
    public CrateListener listener() { return crateListener; }
    public EditorListener editorListener() { return editorListener; }
}
