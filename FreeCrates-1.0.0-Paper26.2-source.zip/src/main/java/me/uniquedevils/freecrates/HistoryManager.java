package me.uniquedevils.freecrates;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class HistoryManager {
    private final FreeCrates plugin;
    private final File file;
    private final YamlConfiguration data;

    public HistoryManager(FreeCrates plugin) {
        this.plugin = plugin;
        file = new File(plugin.getDataFolder(), "history.yml");
        if (!file.exists()) {
            try { file.getParentFile().mkdirs(); file.createNewFile(); } catch (IOException ignored) {}
        }
        data = YamlConfiguration.loadConfiguration(file);
    }

    public void add(Player p, Crate c, Reward r) {
        String path = "players." + p.getUniqueId();
        List<String> list = data.getStringList(path);
        list.add(0, System.currentTimeMillis() + "|" + c.getId() + "|" + r.getId());
        int max = plugin.getConfig().getInt("history.max-per-player", 50);
        while (list.size() > max) list.remove(list.size() - 1);
        data.set(path, list);
        save();
    }

    public List<String> get(Player p) {
        return data.getStringList("players." + p.getUniqueId());
    }

    public void save() {
        try { data.save(file); } catch (IOException e) {
            plugin.getLogger().warning("Could not save history.yml: " + e.getMessage());
        }
    }
}
