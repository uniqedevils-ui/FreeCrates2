package me.uniquedevils.freecrates;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Util {
    private Util() {}

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    public static Component component(String s) {
        return Component.text(color(s));
    }

    public static String plain(String s) {
        return ChatColor.stripColor(color(s == null ? "" : s));
    }

    public static ItemStack item(Material material, String name) {
        ItemStack item = new ItemStack(material == null ? Material.CHEST : material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(component(name));
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack item(Material material, String name, int amount) {
        ItemStack item = item(material, name);
        item.setAmount(Math.max(1, Math.min(item.getMaxStackSize(), amount)));
        return item;
    }

    public static ItemStack item(Material material, String name, String... loreLines) {
        ItemStack item = item(material, name);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.lore(lore(loreLines));
            item.setItemMeta(meta);
        }
        return item;
    }

    public static String itemName(ItemStack item) {
        if (item == null || item.getType().isAir()) return "Empty";
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) return plain(meta.displayName().toString());
        return item.getType().name();
    }

    public static List<String> lore(String... lines) {
        List<String> out = new ArrayList<>();
        for (String line : lines) out.add(color(line));
        return out;
    }

    public static String replace(String text, String... pairs) {
        String out = text;
        for (int i = 0; i + 1 < pairs.length; i += 2) out = out.replace(pairs[i], pairs[i + 1]);
        return out;
    }

    public static void msg(Player p, String message) {
        p.sendMessage(component(message));
    }

    public static Sound sound(String value, Sound fallback) {
        try {
            return Sound.valueOf(value.toUpperCase(Locale.ROOT));
        } catch (Exception e) {
            return fallback;
        }
    }

    public static Material material(String value, Material fallback) {
        try {
            return Material.valueOf(value.toUpperCase(Locale.ROOT));
        } catch (Exception e) {
            return fallback;
        }
    }
}
