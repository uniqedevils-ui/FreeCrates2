package me.uniquedevils.freecrates;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.HashMap;
import java.util.Map;

public final class ChatInput implements Listener {
    private static final Map<Player, Request> waiting = new HashMap<>();

    private record Request(String type, FreeCrates plugin, Crate crate, Reward reward) {}

    static {
        // Listener is registered by the plugin command/editor bootstrap below.
    }

    private ChatInput() {}

    public static void await(Player p, String type, FreeCrates plugin, Crate crate, Reward reward) {
        waiting.put(p, new Request(type, plugin, crate, reward));
    }

    @EventHandler
    public void chat(AsyncPlayerChatEvent e) {
        Request req = waiting.remove(e.getPlayer());
        if (req == null) return;
        e.setCancelled(true);
        String text = e.getMessage().trim();
        Bukkit.getScheduler().runTask(req.plugin(), () -> {
            Player p = e.getPlayer();
            if (text.equalsIgnoreCase("cancel")) {
                p.sendMessage(Util.component("&cCancelled."));
                req.plugin().getServer().getPluginManager().getRegisteredListeners(req.plugin()).forEach(x -> {});
                return;
            }
            switch (req.type()) {
                case "create" -> {
                    if (req.plugin().crates().get(text) != null || text.isBlank()) {
                        p.sendMessage(Util.component("&cThat crate already exists or the name is invalid."));
                        return;
                    }
                    req.plugin().crates().create(text);
                    p.sendMessage(Util.component("&aCreated crate &f" + text + "&a."));
                    req.plugin().editorListener().openMain(p);
                }
                case "name" -> {
                    req.crate().setDisplayName(text);
                    req.plugin().crates().save();
                    req.plugin().editorListener().openMain(p);
                }
                case "keyname" -> {
                    req.crate().setKeyName(text);
                    req.plugin().crates().save();
                    req.plugin().editorListener().openMain(p);
                }
                case "rewardname" -> {
                    req.reward().setDisplayName(text);
                    req.plugin().crates().save();
                    p.sendMessage(Util.component("&aReward name saved."));
                }
            }
        });
    }
}
