package me.uniquedevils.freecrates;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

public class Crate {
    private final String id;
    private String displayName;
    private Material icon;
    private String keyName;
    private String animation;
    private final List<Reward> rewards = new ArrayList<>();

    public Crate(String id) {
        this.id = id;
        this.displayName = "&b" + id;
        this.icon = Material.CHEST;
        this.keyName = "&b" + id + " Key";
        this.animation = "CSGO";
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String v) { displayName = v; }
    public Material getIcon() { return icon; }
    public void setIcon(Material v) { icon = v; }
    public String getKeyName() { return keyName; }
    public void setKeyName(String v) { keyName = v; }
    public String getAnimation() { return animation; }
    public void setAnimation(String v) { animation = v; }
    public List<Reward> getRewards() { return rewards; }
}
