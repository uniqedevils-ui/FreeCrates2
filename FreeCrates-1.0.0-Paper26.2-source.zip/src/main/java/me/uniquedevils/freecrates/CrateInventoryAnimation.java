package me.uniquedevils.freecrates;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CrateInventoryAnimation {
    private final FreeCrates plugin;
    private final Player player;
    private final Crate crate;
    private final Random random = new Random();
    private final int[] rewardSlots = {10,11,12,13,14,15,16};
    private Inventory inv;
    private Reward winner;
    private int ticks;

    public CrateInventoryAnimation(FreeCrates plugin, Player player, Crate crate) {
        this.plugin = plugin;
        this.player = player;
        this.crate = crate;
        this.winner = plugin.crates().pick(crate);
    }

    public void start() {
        inv = Bukkit.createInventory(null, 27, Util.component(crate.getDisplayName() + " &8• Opening"));
        player.openInventory(inv);
        fill();
        int duration = Math.max(20, plugin.getConfig().getInt("animation.duration-ticks", 80));
        int interval = Math.max(1, plugin.getConfig().getInt("animation.interval-ticks", 4));

        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!player.isOnline() || !player.getOpenInventory().getTopInventory().equals(inv)) {
                task.cancel();
                return;
            }
            ticks += interval;
            if (ticks >= duration) {
                showWinner();
                task.cancel();
                return;
            }
            spin();
        }, 0L, interval);
    }

    private void fill() {
        Material filler = Util.material(plugin.getConfig().getString("animation.filler-material"), Material.GRAY_STAINED_GLASS_PANE);
        ItemStack pane = Util.item(filler, "&7");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        for (int slot : rewardSlots) inv.setItem(slot, randomItem());
        inv.setItem(13, Util.item(Material.NETHER_STAR, "&e&l???", 1));
    }

    private ItemStack randomItem() {
        if (crate.getRewards().isEmpty()) return Util.item(Material.BARRIER, "&cNo rewards");
        Reward r = crate.getRewards().get(random.nextInt(crate.getRewards().size()));
        ItemStack item = r.getItem();
        if (item == null || item.getType().isAir()) item = Util.item(Material.CHEST, r.getDisplayName());
        item.setAmount(1);
        return item;
    }

    private void spin() {
        for (int i = 0; i < rewardSlots.length; i++) inv.setItem(rewardSlots[i], randomItem());
        player.playSound(player.getLocation(),
                Util.sound(plugin.getConfig().getString("sounds.click"), Sound.UI_BUTTON_CLICK), 0.5f, 1.3f);
    }

    private void showWinner() {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, Util.item(Material.BLACK_STAINED_GLASS_PANE, "&7"));
        ItemStack item = winner.getItem();
        if (item == null || item.getType().isAir()) item = Util.item(Material.NETHER_STAR, winner.getDisplayName());
        item.setAmount(1);
        inv.setItem(13, item);
        inv.setItem(11, Util.item(Material.LIME_STAINED_GLASS_PANE, "&a&lWINNER"));
        inv.setItem(15, Util.item(Material.LIME_STAINED_GLASS_PANE, "&a&lWINNER"));

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                player.closeInventory();
                plugin.listener().executeReward(player, crate, winner);
            }
        }, 30L);
    }
}
