package me.uniquedevils.freecrates;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class Reward {
    private final String id;
    private String displayName;
    private String rarity;
    private double chance;
    private boolean broadcast;
    private ItemStack item;
    private final List<String> commands = new ArrayList<>();

    public Reward(String id) {
        this.id = id;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String v) { displayName = v; }
    public String getRarity() { return rarity; }
    public void setRarity(String v) { rarity = v; }
    public double getChance() { return chance; }
    public void setChance(double v) { chance = v; }
    public boolean isBroadcast() { return broadcast; }
    public void setBroadcast(boolean v) { broadcast = v; }
    public ItemStack getItem() { return item == null ? null : item.clone(); }
    public void setItem(ItemStack v) { item = v == null ? null : v.clone(); }
    public List<String> getCommands() { return commands; }
}
