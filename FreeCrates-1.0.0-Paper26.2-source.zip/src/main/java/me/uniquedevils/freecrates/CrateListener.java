package me.uniquedevils.freecrates;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class CrateListener implements Listener {
    private final FreeCrates plugin;

    public CrateListener(FreeCrates plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        // Crates are identified by a persistent key on the placed container.
        if (block.getType() != Material.CHEST && block.getType() != Material.BARREL) return;
        String id = block.getState().getPersistentDataContainer()
                .get(new org.bukkit.NamespacedKey(plugin, "crate"), org.bukkit.persistence.PersistentDataType.STRING);
        if (id == null) return;

        event.setCancelled(true);
        Crate crate = plugin.crates().get(id);
        if (crate != null) open(event.getPlayer(), crate);
    }

    public void open(Player player, Crate crate) {
        if (!player.hasPermission("freecrates.use")) {
            Util.msg(player, plugin.getConfig().getString("prefix") + plugin.getConfig().getString("messages.no-permission"));
            return;
        }

        boolean used = plugin.keys().consumePhysical(player, crate);
        if (!used) used = plugin.keys().consumeVirtual(player, crate);

        if (!used) {
            String msg = plugin.getConfig().getString("messages.no-key");
            Util.msg(player, plugin.getConfig().getString("prefix") + Util.replace(msg, "%crate%", Util.plain(crate.getDisplayName())));
            return;
        }

        Util.msg(player, plugin.getConfig().getString("prefix") +
                Util.replace(plugin.getConfig().getString("messages.opening"), "%crate%", Util.plain(crate.getDisplayName())));

        player.playSound(player.getLocation(),
                Util.sound(plugin.getConfig().getString("sounds.click"), Sound.UI_BUTTON_CLICK), 1f, 1f);

        CrateInventoryAnimation animation = new CrateInventoryAnimation(plugin, player, crate);
        animation.start();
    }

    public void executeReward(Player player, Crate crate, Reward reward) {
        if (reward.getItem() != null && !reward.getItem().getType().isAir()) {
            player.getInventory().addItem(reward.getItem());
        }
        for (String command : reward.getCommands()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    command.replace("%player%", player.getName())
                           .replace("%uuid%", player.getUniqueId().toString()));
        }

        plugin.history().add(player, crate, reward);

        String won = plugin.getConfig().getString("messages.won", "&aYou won %reward%");
        Util.msg(player, plugin.getConfig().getString("prefix") +
                Util.replace(won, "%reward%", Util.plain(reward.getDisplayName()), "%crate%", Util.plain(crate.getDisplayName())));
        player.playSound(player.getLocation(),
                Util.sound(plugin.getConfig().getString("sounds.win"), Sound.ENTITY_PLAYER_LEVELUP), 1f, 1f);

        if (reward.isBroadcast() && plugin.getConfig().getBoolean("broadcast.enabled", true)) {
            String broadcast = plugin.getConfig().getString("messages.rare-broadcast");
            Bukkit.broadcastMessage(Util.color(Util.replace(broadcast,
                    "%player%", player.getName(),
                    "%reward%", Util.plain(reward.getDisplayName()),
                    "%crate%", Util.plain(crate.getDisplayName()))));
            player.playSound(player.getLocation(),
                    Util.sound(plugin.getConfig().getString("sounds.rare"), Sound.UI_TOAST_CHALLENGE_COMPLETE), 1f, 1f);
        }
    }
}
