package me.uniquedevils.freecrates;

import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CratesCommand implements CommandExecutor, TabCompleter {
    private final FreeCrates plugin;

    public CratesCommand(FreeCrates plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(new org.bukkit.event.Listener() {}, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Util.component("&b&lFREECRATES &8» &7/crates list, preview, key, virtual, history, editor, reload"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                sender.sendMessage(Util.component("&b&lCRATES"));
                for (Crate c : plugin.crates().getCrates().values())
                    sender.sendMessage(Util.component("&8• &f" + c.getId() + " &7- " + c.getDisplayName()));
            }
            case "preview" -> {
                if (!(sender instanceof Player p)) return true;
                if (!p.hasPermission("freecrates.preview")) { Util.msg(p, "&cNo permission."); return true; }
                if (args.length < 2) { Util.msg(p, "&cUsage: /crates preview <crate>"); return true; }
                Crate c = plugin.crates().get(args[1]);
                if (c == null) { Util.msg(p, "&cCrate not found."); return true; }
                plugin.listener().open(p, c);
            }
            case "editor" -> {
                if (!(sender instanceof Player p)) return true;
                if (!p.hasPermission("freecrates.admin")) { Util.msg(p, "&cNo permission."); return true; }
                plugin.editorListener.openMain(p);
            }
            case "key" -> {
                if (!sender.hasPermission("freecrates.admin")) { sender.sendMessage(Util.component("&cNo permission.")); return true; }
                if (args.length < 3) { sender.sendMessage(Util.component("&cUsage: /crates key <player> <crate> [amount]")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                Crate c = plugin.crates().get(args[2]);
                if (target == null || c == null) { sender.sendMessage(Util.component("&cPlayer or crate not found.")); return true; }
                int amount = args.length >= 4 ? parse(args[3], 1) : 1;
                target.getInventory().addItem(plugin.keys().createKey(c, amount));
                sender.sendMessage(Util.component("&aKeys given."));
            }
            case "virtual" -> {
                if (!sender.hasPermission("freecrates.admin")) { sender.sendMessage(Util.component("&cNo permission.")); return true; }
                if (args.length < 4) { sender.sendMessage(Util.component("&cUsage: /crates virtual <player> <crate> <amount>")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                Crate c = plugin.crates().get(args[2]);
                if (target == null || c == null) { sender.sendMessage(Util.component("&cPlayer or crate not found.")); return true; }
                int amount = parse(args[3], 1);
                plugin.keys().addVirtual(target, c, amount);
                sender.sendMessage(Util.component("&aAdded &f" + amount + " &avirtual keys."));
            }
            case "virtuals" -> {
                if (!(sender instanceof Player p)) return true;
                sender.sendMessage(Util.component("&b&lVIRTUAL KEYS"));
                for (var e : plugin.keys().getVirtual(p).entrySet())
                    sender.sendMessage(Util.component("&8• &f" + e.getKey() + " &7x" + e.getValue()));
            }
            case "history" -> {
                if (!(sender instanceof Player p)) return true;
                sender.sendMessage(Util.component("&b&lYOUR CRATE HISTORY"));
                for (String line : plugin.history().get(p))
                    sender.sendMessage(Util.component("&8• &f" + line));
            }
            case "place" -> {
                if (!(sender instanceof Player p)) return true;
                if (!p.hasPermission("freecrates.admin")) return true;
                if (args.length < 2) { Util.msg(p, "&cUsage: /crates place <crate>"); return true; }
                Crate c = plugin.crates().get(args[1]);
                if (c == null) { Util.msg(p, "&cCrate not found."); return true; }
                // Places a chest and tags it using PDC.
                org.bukkit.block.Block b = p.getTargetBlockExact(5);
                if (b == null || !b.getType().isAir()) { Util.msg(p, "&cLook at an empty block within 5 blocks."); return true; }
                b.setType(org.bukkit.Material.CHEST);
                var state = (org.bukkit.block.TileState) b.getState();
                state.getPersistentDataContainer().set(
                        new org.bukkit.NamespacedKey(plugin, "crate"),
                        org.bukkit.persistence.PersistentDataType.STRING, c.getId());
                state.update();
                Util.msg(p, "&aPlaced &f" + c.getId() + "&a crate.");
            }
            case "reload" -> {
                if (!sender.hasPermission("freecrates.admin")) { sender.sendMessage(Util.component("&cNo permission.")); return true; }
                plugin.reloadConfig();
                plugin.crates().load();
                sender.sendMessage(Util.component("&aFreeCrates reloaded."));
            }
            default -> sender.sendMessage(Util.component("&cUnknown subcommand."));
        }
        return true;
    }

    private int parse(String s, int fallback) {
        try { return Math.max(1, Integer.parseInt(s)); } catch (Exception e) { return fallback; }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return filter(Arrays.asList("list","preview","editor","key","virtual","virtuals","history","place","reload"), args[0]);
        if (args.length == 2 && Arrays.asList("preview","place").contains(args[0].toLowerCase()))
            return filter(new ArrayList<>(plugin.crates().getCrates().keySet()), args[1]);
        if (args.length == 3 && Arrays.asList("key","virtual").contains(args[0].toLowerCase()))
            return null;
        if (args.length == 3 && Arrays.asList("key","virtual").contains(args[0].toLowerCase()))
            return filter(new ArrayList<>(plugin.crates().getCrates().keySet()), args[2]);
        return List.of();
    }

    private List<String> filter(List<String> values, String prefix) {
        List<String> out = new ArrayList<>();
        for (String v : values) if (v.toLowerCase().startsWith(prefix.toLowerCase())) out.add(v);
        return out;
    }
}
