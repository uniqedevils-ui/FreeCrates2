# FreeCrates

Free, original premium-style crate plugin for **Paper 26.2**.

## What it includes

- Java + Bedrock crossplay compatibility through Geyser/Floodgate.
- `/crates editor` GUI.
- Create/delete/manage crates.
- Reward editor.
- Reward chance editing.
- Rarity cycling: COMMON, UNCOMMON, RARE, EPIC, LEGENDARY, ULTRA.
- Broadcast toggle for rare rewards.
- Physical keys.
- Virtual keys.
- Animated reward opening.
- Reward preview.
- Win history.
- Console reward commands with `%player%` and `%uuid%`.
- Configurable messages, sounds and animation timing.
- No paid license and no required economy dependency.
- YAML storage.
- Custom crate placement with `/crates place <crate>`.

## Build

Requires JDK 25 and Gradle 9.1+.

```bash
gradle build
```

The plugin jar will be in `build/libs/`.

## Server

Use Paper 26.2. For Bedrock players, install Geyser and optionally Floodgate. The plugin itself is Java-side; Geyser translates Bedrock connections to the Java server.

## Main commands

- `/crates list`
- `/crates editor`
- `/crates preview <crate>`
- `/crates key <player> <crate> [amount]`
- `/crates virtual <player> <crate> <amount>`
- `/crates virtuals`
- `/crates history`
- `/crates place <crate>`
- `/crates reload`

## Important

This is an original implementation inspired by the feature set you requested. It does not copy Phoenix Crates or Exclusive Crates source code/assets.

The editor uses normal Paper inventory menus so Bedrock players connected through Geyser can use the same menus. Geyser has some unavoidable inventory interaction differences, so the editor avoids depending on left-vs-right click behavior.
